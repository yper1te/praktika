<link rel="stylesheet" href="styles.css">
<form class="auth_form" action="avt_script.php" method="post">
  <h2>Авторизация</h2>
  <input type="text" class="username_field" placeholder="Имя" name="username">
  <input type="password" class="password_field" placeholder="Пароль" name="password">
  <input type="submit" class="auth_button" value="Autoriz">
</form>
