<?php
session_start();
include("config_bd.php");
$mysqli = mysqli_connect($server_name, $bd_user, $bd_password, $bd_name);
if ($mysqli->connect_errno) {
    printf("Соединение не удалось: %s\n", $mysqli->connect_error);
    exit();
}


    $login = $_POST['username'];
    $pas = $_POST['password'];
    $sql = "SELECT * FROM users WHERE login = '$login' AND password = '$pas'";
    $result = $mysqli->query($sql);

  
    if ($result->num_rows > 0) {
        $_SESSION['user_id'] = 1;
        header("Location: indexmain.php"); 
        exit();
    } else {
        
        echo "<p class='error'>Пользователь не найден.</p>";
    }

?>