<?php
 $server_name="localhost";
 $bd_user="root";
 $bd_password="";
 $bd_name="praktika";
 ?>