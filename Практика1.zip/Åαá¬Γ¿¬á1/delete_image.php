<?php
include("config_bd.php");

if(isset($_POST['id'])) {
    $id = $_POST['id'];

    $mysqli = mysqli_connect($server_name, $bd_user, $bd_password, $bd_name);
    if ($mysqli->connect_errno) {
        printf("Соединение не удалось: %s\n", $mysqli->connect_error);
        exit();
    }

    // Удаление изображения по id
    $sql = "DELETE FROM images WHERE id = $id";
    if ($mysqli->query($sql)) {
        header("Location: index2.php"); 
    } else {
        echo "Ошибка при удалении изображения: " . $mysqli->error;
    }

    $mysqli->close();
} else {
    echo "Ошибка: id изображения не был передан.";
}
?>