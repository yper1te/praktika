<?php
include("config_bd.php");
$mysqli = mysqli_connect($server_name, $bd_user, $bd_password, $bd_name, $bd_port);
if ($mysqli->connect_errno) {
    printf("Соединение не удалось: %s\n", $mysqli->connect_error);
    exit();
}

$id = $_POST['id'];
$descr = $_POST['about'];

$sql = "UPDATE images SET about = '$descr' WHERE id = $id";
if ($mysqli->query($sql) === TRUE) {
    header("Location: index2.php"); 
} else {
    echo "Ошибка при обновлении названия фотографии: " . $mysqli->error;
}

$mysqli->close();
?>
