<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BeSt_MaNgA 🥰</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
   
        <div class="container">
            <h1>BeSt_MaNgA 🥰</h1>
            <div class="auth-container">
                <a class="auth-button" href="avt.php">Войти</a>
                <a class="auth-button" href="reg.php">Регистрация</a>
            </div>
        </div>
    </header>
</body>
</html>
