<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BeSt_MaNgA 🥰</title>
    <link rel="stylesheet" href="style.css">
</head>
<header>
        <div class="container">
            <h1>BeSt_MaNgA 🥰</h1>
            <div class="auth-container">
                <a class="auth-button" href="indexmain.php">Главная</a>
                <a class="auth-button" href="index1.php">Личный Кабинет</a>
                <a class="auth-button" href="logout.php">Выход</a>
            </div>
        </div>
    </header>
