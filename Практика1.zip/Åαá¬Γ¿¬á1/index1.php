<?php include('header_auth.php'); ?>
<link rel="stylesheet" type="text/css" href="styless.css">
<?php
include("config_bd.php");

session_start();

$mysqli = mysqli_connect($server_name, $bd_user, $bd_password, $bd_name);
if ($mysqli->connect_errno) {
    printf("Соединение не удалось: %s\n", $mysqli->connect_error);
    exit();
}

$is_logged_in = isset($_SESSION['user_id']);

if ($is_logged_in) {
    echo "<form class='upload_form' action='photo_scr.php' method='post' enctype='multipart/form-data'>";
    echo "<h3>Добавить новую мангу/манхву:</h3>";
    echo "<input type='file' name='photo' required>";
    echo "<input type='text' name='author' placeholder='Автор' required>";
    echo "<input type='text' name='descr' placeholder='Описание' required>";
    echo "<input type='text' name='age' placeholder='Возрастные ограничения' required>";
    echo "<select name='type' required>";
    echo "<option value='manga'>Манга</option>";
    echo "<option value='manhwa'>Манхва</option>";
    echo "</select>";
    echo "<input type='date' name='last' placeholder='Дата добавления' required>";
    echo "<input type='submit' value='Отправить'>";
    echo "</form>";

    echo "<form class='upload_form' action='index2.php' method='post' enctype='multipart/form-data'>";
    echo "<input type='submit' value='Редактирование'>";
    echo "</form>";
}   


$sql2 = "SELECT * FROM images";
$result2 = $mysqli->query($sql2);
if ($result2->num_rows > 0) {
    echo "<div class='column-container'>";
    while ($row = $result2->fetch_assoc()) {
        $authorValue = $row["author"];
        $photoUrl = $row["img_src"];
        $descrValue = $row["about"];
        echo "<div class='image-container' style='display: inline-block; margin-right: 10px;'>";
        echo "<p class='title'>$authorValue</p>";
        echo "<img src='$photoUrl' style='width: 150px; width: 200px;'>";
        echo "<p class='description'>$descrValue</p>";
      
        echo "</form>";
        echo "</div>\n";
    }
    echo "</div>";
}

$mysqli->close();
?>
