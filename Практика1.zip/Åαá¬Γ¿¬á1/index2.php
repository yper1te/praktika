<?php include ('header_auth.php')?>
<link rel="stylesheet" type="text/css" href="stylesss.css">
<form class='search_form' action='' method='post' enctype='multipart/form-data'>
    <label name='avvt'>Введите свой ник-автор для ваших картин:</label>
    <input type='text' name='author' placeholder='Автор'>
    <input type='submit' name="submit" value='Отправить'>
</form>


<?php
include("config_bd.php");

session_start();

$mysqli = mysqli_connect($server_name, $bd_user, $bd_password, $bd_name);
if ($mysqli->connect_errno) {
    printf("Соединение не удалось: %s\n", $mysqli->connect_error);
    exit();
}

// Проверяем, была ли отправлена форма с именем автора
if(isset($_POST['submit']) && isset($_POST['author'])) {
    $author = $_POST['author'];
    $sql = "SELECT * FROM images WHERE author = '$author'";
    $result = $mysqli->query($sql);

    if ($result->num_rows > 0) {
        // Если найдены записи с указанным автором, сохраняем автора в сессионной переменной
        $_SESSION['author'] = $author;
        echo "<div class='column-container'>";
        while ($row = $result->fetch_assoc()) {
            $id = $row["id"];
            $authorValue = $row["author"];
            $photoUrl = $row["img_src"];
            $descrValue = $row["about"];
            echo "<div class='image-container' style='display: inline-block; margin-right: 10px;'>";
            echo "<p class='title'>$authorValue</p>";
            echo "<img src='$photoUrl' style='width: 150px;width: 200px;'>";
            echo "<p class='description'>$descrValue</p>";
            echo "<form action='edit_scr.php' method='post'>";
            echo "<input type='hidden' id='id' name='id' value='$id'>";
            echo "<input type='text' id='about' name='about' value='$descrValue'>";
            echo "<input type='submit' value='Редактировать'>";
            echo "</form>";
            // Форма для удаления картинки
            echo "<form action='delete_image.php' method='post'>";
            echo "<input type='hidden' id='id' name='id' value='$id'>";
            echo "<input type='submit' value='Удалить'>";
            echo "</form>";
            echo "</div>\n";
        }
        echo "</div>";
    } else {
        echo "<p>Картинок с указанным автором не найдено.</p>";
    }
}

$mysqli->close();
?>


<form class='search_form' action='index1.php' method='post' enctype='multipart/form-data'>
    <input type='submit' value='Вернуться'>
</form>