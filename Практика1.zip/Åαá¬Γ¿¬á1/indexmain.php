<?php
include("config_bd.php");
include("header_auth.php");
session_start();

$mysqli = mysqli_connect($server_name, $bd_user, $bd_password, $bd_name);
if ($mysqli->connect_errno) {
    printf("Соединение не удалось: %s\n", $mysqli->connect_error);
    exit();
}

// Подготовка SQL-запроса для отображения отфильтрованных данных
$sql = "SELECT author, about, img_src FROM images WHERE 1";

// Проверяем, была ли отправлена форма фильтров
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Фильтр по типу (манга или манхва)
    if (isset($_POST['types']) && $_POST['types'] != '') {
        $type = $mysqli->real_escape_string($_POST['types']);
        $sql .= " AND type = '$type'";
    }

    // Фильтр по возрастным ограничениям
    if (isset($_POST['caution_list'])) {
        $cautions = $_POST['caution_list'];
        $caution_conditions = [];

        foreach ($cautions as $caution) {
            $escaped_caution = $mysqli->real_escape_string($caution);
            $caution_conditions[] = "age = '$escaped_caution'";
        }

        if (!empty($caution_conditions)) {
            $sql .= " AND (" . implode(" OR ", $caution_conditions) . ")";
        }
    }

    // Сортировка результатов
    if (isset($_POST['sort']) && $_POST['sort'] != '') {
        $sort_by = $mysqli->real_escape_string($_POST['sort']);
        if ($sort_by == 'last_chapter_at') {
            // Заменяем на существующее поле, например, 'last' для даты добавления
            $sort_by = 'last';
        }
        $sql .= " ORDER BY $sort_by";
    }
}

// Выполнение SQL-запроса
$result = $mysqli->query($sql);

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Отфильтрованные данные</title>
    <link rel="stylesheet" href="style.css"> <!-- Подключите ваш файл со стилями -->
</head>
<body>
    <main>
        <div class="container">
            <aside>
                <h2>Фильтры</h2>
                <form id="filters" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                    <label for="sort">Сортировать по:</label>
                    <select id="sort" name="sort">
                        <option value="last_chapter_at">Дата добавления</option>
                        <option value="author">Название</option>
                    </select>
                    
                    <label for="types">Тип:</label>
                    <select id="types" name="types">
                        <option value="manga">Манга</option>
                        <option value="manhwa">Манхва</option>
                    </select>
                    
                    <fieldset>
                        <legend>Возрастные ограничения:</legend>
                        <label><input type="checkbox" name="caution_list[]" value="Отсутствует"> Отсутствует</label>
                        <label><input type="checkbox" name="caution_list[]" value="16+"> 16+</label>
                        <label><input type="checkbox" name="caution_list[]" value="18+"> 18+</label>
                    </fieldset>
                    
                    <button type="submit">Применить</button>
                </form>
            </aside>

            <section class="manga-list">
                <?php
                if ($result->num_rows > 0) {
                    echo "<div class='column-container'>";
                    while ($row = $result->fetch_assoc()) {
                        $avtValue = $row["author"];
                        $fotoUrl = $row["img_src"];
                        $opsValue = $row["about"];
                        echo "<div class='image-container' style='display: inline-block; margin-right: 10px;'>";
                        echo "<p class='title'>$avtValue</p>";
                        echo "<img src='$fotoUrl' style='width: 150px;width: 200px;'>";
                        echo "<p class='description'>$opsValue</p>";
                        echo "</div>\n";
                    }
                    echo "</div>";
                } else {
                    echo "<p>Нет результатов, удовлетворяющих заданным фильтрам.</p>";
                }
                $mysqli->close();
                ?>
            </section>
        </div>
    </main>
</body>
</html>
