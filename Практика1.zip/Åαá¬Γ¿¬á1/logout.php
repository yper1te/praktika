<?php
session_abort();
include("config_bd.php");
$mysqli = mysqli_connect($server_name, $bd_user, $bd_password, $bd_name);
if ($mysqli->connect_errno) {
    printf("Соединение не удалось: %s\n", $mysqli->connect_error);
    exit();
}

    header("Location: index.php"); 

?>