<?php
include("config_bd.php");

$mysqli = mysqli_connect($server_name, $bd_user, $bd_password, $bd_name);
if ($mysqli->connect_errno) {
    printf("Соединение не удалось: %s\n", $mysqli->connect_error);
    exit();
}

$uploaddir = __DIR__ . '/img/';
$uploadfile = $uploaddir . basename($_FILES['photo']['name']);

if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
    $author = $mysqli->real_escape_string($_POST["author"]);
    $descr = $mysqli->real_escape_string($_POST["descr"]);
    $photo = 'img/' . basename($_FILES['photo']['name']);
    $age = $mysqli->real_escape_string($_POST["age"]);
    $type = $mysqli->real_escape_string($_POST["type"]);
    $last = $mysqli->real_escape_string($_POST["last"]);

    $sql = "INSERT INTO images (author, img_src, about, age, type, last) 
            VALUES ('$author', '$photo', '$descr', '$age', '$type', '$last')";
    
    if ($mysqli->query($sql) === TRUE) {
        header("Location: index1.php");
        exit();
    } else {
        echo "Ошибка: " . $sql . "<br>" . $mysqli->error;
    }
} else {
    echo "Ошибка при загрузке файла.";
}

$mysqli->close();
?>
