<link rel="stylesheet" href="styles.css">
<form class="reg_form" action="reg_script.php" method="post"> 
        <h2>Регистрация</h2>
        <input type="text" class="input_field" placeholder="Имя" name="username"> 
       
        <input type="password" class="input_field" placeholder="Пароль" name="password"> 
        <input type="submit" class="submit_button" value="Регистрация"> 
    </form>