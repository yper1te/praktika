<?php
session_start();
include("config_bd.php");
$mysqli = mysqli_connect($server_name, $bd_user, $bd_password, $bd_name);
if ($mysqli->connect_errno) {
    printf("Соединение не удалось: %s\n", $mysqli->connect_error);
    exit();
}

$login = $_POST['username'];
$pass = $_POST['password'];
$sql = "SELECT * FROM users WHERE login = '$login'";
$result = $mysqli->query($sql);
if ($result->num_rows > 0){
    echo "<p class='error'>Пользователь уже зарегистрирован</p>";
}
else{
    $sql = "insert into users (login,password) values ('$login','$pass')";
    $result = $mysqli->query($sql);
    
    if ($result == true) {
        $_SESSION['username'] = $login;
        header("Location: indexmain.php"); 
        exit();
    } else {
        echo "<p class='error'>Ошибка.</p>";
    }
}
?>